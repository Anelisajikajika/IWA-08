const leoName = 'Leo Musvaire'
const leoNumber = '2'
const leoStreet = 'Church St.'
const leoPostal = '3105'
const leoBalance = '-10'
 

const sarahName = 'Sarah Kleinhans'
const sarahBalance = '-4582.21000111'
const sarahNumber = '13'
const sarahStreet = 'William Close'
const sarahPostal = '0310'

// Only change below this line

if (leoName == 'Leo Musvaire'){
	balance = 'leoBalance'

	age = 24
}

	if( Address =leoNumber+leoStreet ){
	 postal = leoPostal
	}
	leoaccessId = 47-8014-4-40203

if  (name == 'sarahName' + 'sarahSurname'){
	age = 62
	sarahaccessId = 6-5657-4240-80e9-23
	balance = 'sarahBalance' 
}
	if(address =sarahNumber+sarahStreet) {
		postal = sarahPostal
	}
console.log(leoName + leoNumber + leoStreet + leoPostal)
console.log(sarahName+sarahNumber + sarahStreet +sarahPostal)	